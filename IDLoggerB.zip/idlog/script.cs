//it works!

%name="Bob";
//getFileCount() is the source of the problem?

%fileCount = getFileCount("config/client/idlog/ids/*");
for(%i=0;%i<=%fileCount;%i++)
{
	if(%i==0)
	{
		%file=findFirstFile("config/client/idlog/ids/*.log");
	}
	else
	{
		%file=findNextFile("config/client/idlog/ids/*.log");
	}
	
	echo(%i@" - "@%file);
	%FO = new fileobject();
	%FO.openForRead(%file);
	
	if(%FO.readLine()$=%name)
	{
		echo(">"@%file);break;
	}
	%FO.close();
}